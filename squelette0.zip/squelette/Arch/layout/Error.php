<div class="a_card">
  <div class="a_card-header"><span class="a_card-header-title"></span></div>
  <div class="a_card-body a_error_card">
    <div class="p_error">
      <span>ERROR YOU STUPIDDD
      </span>
    </div>
  </div>
</div>

Setting up submarine . . .

<div class="a_card">
  <div class="a_card-header"><span class="a_card-header-title"></span></div>
  <div class="a_card-body">
    <div class="a_card-body-block row">
      <div class="a_card-item col">
        <span>You have been logged out
        </span>
      </div>
    </div>
  </div>
</div>

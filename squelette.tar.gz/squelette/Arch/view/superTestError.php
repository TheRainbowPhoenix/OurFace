


<div class="a_card">
  <div class="a_card-header"><span class="a_card-header-title"></span></div>
  <div class="a_error_card a_card-body">
    <div class="p_error">
      <span>ERROR YOU STUPIDDD
      </span>
    </div>
  </div>
</div>
